<div class="container right" style="width: 700px; height:auto;border-radius: 10px; border: solid #818181 1px; display:flex;flex-direction:column; margin-top:21px">
        <div class="right-one" style="display: flex; align-content: center; ">
            <p style="margin: 11px 0px 0px 331px; width: auto;">Nbre de question/Jeu </p>
            <input type="email" class="form-control  ml-2 pt-2 " style="height: 30px; width:40px;margin-top:10px;" placeholder="5" id="exampleInputEmail1" aria-describedby="emailHelp">
            <button type="submit" class="btn  pt-2" style=" width:60px;height:40px ; background-color:#3addd6 ; color: #f8fdfd;margin: 5px 7px 0px 6px" >OK</button>
        </div>
        <div class="right-deux" style="border:solid 1px #818181; height: auto;border-radius: 10px;">
        <ol > <li style="color: #818181">Les languages du web</li> 
          <ul type="square"> 
          <li>HTML </li>
          <li> R </li>
          <li> JAVA</li>
          </ul>
          <li style="color: #818181">D'ou vient le corona ?</li> 
          <ul>
          <li>ITALIE </li>
          <li> CHINE</li>
          </ul>
          <li style="color: #818181"> Quel terme déﬁnit langage qui s’adapte sur     Androïd et sur Ios</li> 
          <input type="email" class="form-control  pt-2 " style="height: 30px; width:150px" placeholder="" id="exampleInputEmail1" aria-describedby="emailHelp">
          <li style="color: #818181">Quelle est la première école de codage gratuite     au Sénégal</li> 
          <ul > 
          <li>Simplon </li>
          <li> Orange Digitale Center</li>
          </ul>
          <li style="color: #818181">Les précurseurs de la révolution digitale</li> 
          <ul> 
          <li>GAFAM </li>
          <li> CIA-FBI</li>
          </ul>
        </ol> 
        
      </div>
      <button type="submit" class="btn   pt-2" style=" width:100px;height:40px ; background-color:#3addd6 ; color: #f8fdfd;margin: 4px 7px 0px 525px" > Suivant </button>
        </div>
    </div>