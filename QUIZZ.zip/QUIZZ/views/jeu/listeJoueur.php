<div class="container right" style="width: 700px; height:auto; display:flex;flex-direction:row;margin-top:21px">
        <div class="right-one">
          <h3 style="color: #818181;margin: 10px 0px 8px 123px"> LISTE DES JOUEURS PAR SCORE </h3>   
        <div style="border:solid 1px #51bfd0 ;height: auto;width: auto; border-radius: 10px;">
        <table  style="color: #818181;font-size: 35px;margin-left: 110px;">
          <thead>
            <tr>
              <th >Nom</th>
              <th>Prénom</th>
              <th>Score</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td scope="row">DIATTA</td>
              <td>Ibou</td>
              <td>1022pts</td>
            </tr>
            <tr>
              <td scope="row">NIANG</td>
              <td>Aly</td>
              <td>963pts</td>
            </tr>
            <tr>
              <td scope="row">MBAYE</td>
              <td>Saliou</td>
              <td>877pts</td>
            </tr>
            <tr>
              <td scope="row">DIOUF</td>
              <td>Khady</td>
              <td>875pts</td>
            </tr>
            <tr>
              <td scope="row">SOW</td>
              <td>Moussa</td>
              <td>870pts</td>
            </tr>
            <tr>
              <td scope="row">MBOUP</td>
              <td>Youssou</td>
              <td>816pts</td>
            </tr>
            <tr>
              <td scope="row">DIENG</td>
              <td>Astou</td>
              <td>800pts</td>
            </tr>
            <tr>
              <td scope="row">SAMB</td>
              <td>Ibrahima</td>
              <td>797pts</td>
            </tr>
            <tr>
              <td scope="row">GUEYE</td>
              <td>Léna</td>
              <td>763pts</td>
            </tr>
            <tr>
              <td scope="row">BEYE</td>
              <td>Aminata</td>
              <td>760pts</td>
            </tr>
            <tr>
              <td scope="row">MANE</td>
              <td>Lamine</td>
              <td>759pts</td>
            </tr>
            <tr>
              <td scope="row">MENDES</td>
              <td>Serge</td>
              <td>730pts</td>
            </tr>
            <tr>
              <td scope="row">NDECKY</td>
              <td>Estelle</td>
              <td>723pts</td>
            </tr>
            <tr>
              <td scope="row">DIALLO</td>
              <td>Moustapha</td>
              <td>720pts</td>
            </tr>
            <tr>
              <td scope="row">NDOUR</td>
              <td>Abba</td>
              <td>716pts</td>
            </tr>
           
          </tbody>
        </table>
        </div>
        <button type="submit" class="btn   pt-2" style=" width:100px;height:40px ; background-color:#3addd6 ; color: #f8fdfd;margin: 28px 7px 9px 500px" > Suivant </button>

        </div>
        </div>