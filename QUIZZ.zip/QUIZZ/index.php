<?php
   require_once "libs/Router.php";
   $router=new Router();
   $router->getRoute();
  
