<?php
 interface IManager{
    public function hydrate($row);
 }

?>