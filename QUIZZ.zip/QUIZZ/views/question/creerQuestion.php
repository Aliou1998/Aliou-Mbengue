<div class="container right" style="width: 650px; height:auto; display:flex;flex-direction:column; margin-top:21px">
            <h3 style="color: #51bfd0;">PARAMETRER VOTRE QUESTION  </h3>
            <div class="right-one" style="display: flex; align-content: center; ">
                
                
            </div>
            <div class="right-deux" style="border:solid 1px #3addd6; height: auto;border-radius: 10px; padding-top: 10px;">
              <div style="display: flex; margin-bottom: 20px;">
       <p >Questions </p>
          <input type="email" class="form-control  ml-2 pt-2 " style="border:solid 1px #3addd6; height: 80px; width:450px;margin-top:10px;" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <div style="display: flex;margin-bottom: 20px;">
                <p>Nbre de Points </p>
               
                <select type="email" class="form-control  ml-2 pt-2 " style="border:solid 1px #3addd6;height: 40px; width:80px;margin-top:10px;" id="exampleInputEmail1" aria-describedby="emailHelp">
                </select>
                </div>
              <div style="display: flex;margin-bottom: 20px;">
                <p>Type de Reponse </p>
                <select type="email" class="form-control  ml-2 pt-2 " style="border:solid 1px #3addd6;height: 40px; width:300px;margin-top:10px;margin-right: 5px;"  id="exampleInputEmail1" aria-describedby="emailHelp">
                </select>
               <img src="ic-ajout-réponse.png" height="40px" width="40px" style="margin-top: 10px;">
              </div>
              <div style="display: flex;margin-bottom: 20px;">
                <p>Reponse 1 </p>
                <input type="email" class="form-control  ml-2 pt-2 " style="border:solid 1px #3addd6;height: 40px; width:350px;margin-top:10px;"  id="exampleInputEmail1" aria-describedby="emailHelp">
                <input type="email" class="form-control  ml-2 pt-2 " style="height: 30px; width:30px;margin-top:10px;"  id="exampleInputEmail1" aria-describedby="emailHelp">
                <input type="email" class="form-control  ml-2 pt-2 " style="height: 30px; width:30px;margin-top:10px; border-radius: 20px;"  id="exampleInputEmail1" aria-describedby="emailHelp">
                <img src="ic-supprimer.png" width="20px" height="20px" style="margin: 21px 0px 0px 6px;">
              </div>
              <button type="submit" class="btn   pt-2" style=" width:100px;height:40px ; background-color:#3addd6 ; color: #f8fdfd;margin: 160px 7px 9px 500px" > Enregistrer </button>
           </div>
         
            </div>
        